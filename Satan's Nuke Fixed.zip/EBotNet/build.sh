g++ -s Main.cpp EBotNet.cpp EBotList.cpp SocksTunnel.cpp enet/*.c enet/*.cc growtopia/*.cpp -Ienet/include -lpthread -Wall -O3 -std=gnu++17 -o bot
